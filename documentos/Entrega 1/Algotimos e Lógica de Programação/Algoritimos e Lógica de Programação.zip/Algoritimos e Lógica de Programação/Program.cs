﻿using System;

namespace FugaDoLaboratorio
{
    class Program
    {
        // FUGA DO LABORATÓRIO DE INFORMÁTICA
        // Jogo de console em C# com 3 fases de desafios

        static void Main(string[] args)
        {
            // --- Variáveis do jogo ---
            int energia = 3;
            int pontos = 0;
            int faseAtual = 1;
            bool jogando = true;
            string resposta = "";
            string opcao = "";

            // --- Tela de abertura ---
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("FUGA DO LABORATÓRIO DE INFORMÁTICA");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("Você dormiu durante a aula de programação e acordou");
            Console.WriteLine("com o laboratório trancado e as luzes apagadas...");
            Console.WriteLine();
            Console.WriteLine("Para destrancar a porta eletrônica, você precisa");
            Console.WriteLine("hackear o sistema respondendo 3 desafios.");
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("  Energia inicial : {energia} pontos de vida");
            Console.WriteLine("  Acerto          : +pontos e avança de fase");
            Console.WriteLine("  Erro            : -1 de energia");
            Console.WriteLine("  Energia = 0     : Game Over (você desmaia)");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("Pressione ENTER para começar...");
            Console.ReadLine();

            // LOOP PRINCIPAL DO JOGO
            // Condição: jogando=true, energia > 0, fases restantes

            while (jogando && energia > 0 && faseAtual <= 3)
            {
                Console.Clear();

                // --- Cabeçalho de status ---
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("FASE " + faseAtual + " de 3");
                Console.ResetColor();

                // Barra de energia
                Console.Write("  Energia: ");
                Console.ForegroundColor = energia >= 2 ? ConsoleColor.Green : ConsoleColor.Red;
                for (int i = 0; i < energia; i++) Console.Write("1 ");
                for (int i = energia; i < 3; i++) Console.Write("0 ");
                Console.ResetColor();
                Console.WriteLine($"   Pontos: {pontos}");
                Console.WriteLine();

                // --- Menu de opções ---
                Console.WriteLine("O que você deseja fazer?");
                Console.WriteLine("  [1] Tentar o desafio");
                Console.WriteLine("  [2] Desistir e esperar alguém abrir (Sair)");
                Console.Write("\nSua escolha: ");
                opcao = Console.ReadLine() ?? "";

                // --- Opção de sair ---
                if (opcao == "2")
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.DarkYellow;
                    Console.WriteLine("Você desistiu... Vai ter que dormir");
                    Console.WriteLine("no laboratório até alguém chegar amanhã cedo.");
                    Console.ResetColor();
                    jogando = false;
                    continue;
                }

                // --- Opção inválida ---
                if (opcao != "1")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\nOpção inválida! Tente novamente.");
                    Console.ResetColor();
                    Console.WriteLine("Pressione ENTER para continuar...");
                    Console.ReadLine();
                    continue;
                }

                // FASE 1 — Tipos de Variáveis
                if (faseAtual == 1)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine(" DESAFIO 1 — O Terminal de Acesso ");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("  Você encontra um terminal antigo. Na tela aparece:");
                    Console.WriteLine("  \"Informe o tipo de dado correto para continuar.\"");
                    Console.WriteLine();
                    Console.WriteLine("  Pergunta: Qual tipo de variável em C# é usado");
                    Console.WriteLine("  para armazenar um texto (cadeia de caracteres)?");
                    Console.WriteLine();
                    Console.WriteLine("    a) int");
                    Console.WriteLine("    b) bool");
                    Console.WriteLine("    c) string");
                    Console.Write("\n  Sua resposta (a/b/c): ");
                    resposta = (Console.ReadLine() ?? "").ToLower().Trim();

                    if (resposta == "c")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n  CORRETO! O terminal aceita sua resposta.");
                        Console.WriteLine("  Nível 1 de segurança desbloqueado!");
                        Console.ResetColor();
                        pontos += 10;
                        faseAtual++;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n  ERRADO!");
                        Console.WriteLine("  Você perdeu 1 de energia.");
                        Console.ResetColor();
                        energia--;
                    }
                }

                // FASE 2 — Operadores
                else if (faseAtual == 2)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine(" DESAFIO 2 — O Painel de Controle ");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("  Você chega ao painel de controle da porta.");
                    Console.WriteLine("  Uma tela pede que você identifique o operador:");
                    Console.WriteLine();
                    Console.WriteLine("  Pergunta: Qual operador em C# verifica se dois");
                    Console.WriteLine("  valores são IGUAIS em uma condição?");
                    Console.WriteLine();
                    Console.WriteLine("    a) =");
                    Console.WriteLine("    b) ==");
                    Console.WriteLine("    c) !=");
                    Console.Write("\n  Sua resposta (a/b/c): ");
                    resposta = (Console.ReadLine() ?? "").ToLower().Trim();

                    if (resposta == "b")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n  CORRETO! O painel aceita o código de acesso.");
                        Console.ResetColor();
                        pontos += 10;
                        faseAtual++;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n  ERRADO! Alarme disparado! Você perdeu 1 de energia.");
                        Console.ResetColor();
                        energia--;
                    }
                }

                // FASE 3 — Estruturas de Repetição
                else if (faseAtual == 3)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine(" DESAFIO 3 — A Fechadura Eletrônica ");
                    Console.ResetColor();
                    Console.WriteLine();
                    Console.WriteLine("  Você está na frente da porta! A fechadura pede");
                    Console.WriteLine("  a senha final: a resposta certa destranca tudo.");
                    Console.WriteLine();
                    Console.WriteLine("  Pergunta: Qual estrutura de repetição em C#");
                    Console.WriteLine("  executa um bloco ENQUANTO a condição for verdadeira?");
                    Console.WriteLine();
                    Console.WriteLine("    a) for");
                    Console.WriteLine("    b) if");
                    Console.WriteLine("    c) while");
                    Console.Write("\n  Sua resposta (a/b/c): ");
                    resposta = (Console.ReadLine() ?? "").ToLower().Trim();

                    if (resposta == "c")
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("\n  CORRETO! A fechadura eletrônica se abre!");
                        Console.ResetColor();
                        pontos += 10;
                        faseAtual++;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("\n  ERRADO! Sistema bloqueado temporariamente.");
                        Console.WriteLine("  Você perdeu 1 de energia.");
                        Console.ResetColor();
                        energia--;
                    }
                }

                Console.WriteLine();
                Console.WriteLine("Pressione ENTER para continuar...");
                Console.ReadLine();
            }

            // TELA FINAL
            Console.Clear();

            if (!jogando && faseAtual <= 3)
            {
                // Jogador desistiu
                Console.ForegroundColor = ConsoleColor.DarkYellow;
                Console.WriteLine("VOCÊ DESISTIU...");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Você se acomodou entre dois computadores e tentou");
                Console.WriteLine("dormir. Alguém te encontrou às 6h da manhã.");
            }
            else if (energia <= 0)
            {
                // Energia zerada — derrota
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("GAME OVER!");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Sua energia acabou e você desmaiou de exaustão.");
                Console.WriteLine("Alguém te encontrou babando no teclado às 7h.");
            }
            else if (faseAtual > 3)
            {
                // Todas as fases concluídas — vitória
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("PARABÉNS! VOCÊ ESCAPOU!");
                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine("Você desbloqueou todas as fases de segurança e");
                Console.WriteLine("a porta se abriu.");
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.ResetColor();
            }

            // Pontuação final
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"  Pontuacao Final : {pontos} pontos");
            Console.WriteLine($"  Energia restante: {energia}");
            Console.ResetColor();
            Console.WriteLine();
            Console.WriteLine("Pressione qualquer tecla para sair");
            Console.ReadKey();
        }
    }
}
